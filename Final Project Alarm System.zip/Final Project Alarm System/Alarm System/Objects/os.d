.\objects\os.o: os.c
.\objects\os.o: D:\ARM Files\Kiel_V5\ARM\ARM_Compiler_5.06u7\Bin\..\include\stdint.h
.\objects\os.o: os.h
.\objects\os.o: ../inc/CortexM.h
.\objects\os.o: ../inc/BSP.h
